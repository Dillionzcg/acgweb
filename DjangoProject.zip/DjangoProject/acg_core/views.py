from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from .forms import RegisterForm, LoginForm  # ⬅️ 引用刚才写的 forms
from django.contrib.auth import get_user_model
from django.shortcuts import render

def index(request):
    # 这里的 logic 是渲染你的主页
    return render(request, 'index.html') # 或者是你之前用的模板名

User = get_user_model()

def register_view(request):
    form = RegisterForm()
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            # 数据校验通过，创建用户
            data = form.cleaned_data
            user = User.objects.create_user(
                username=data['username'],
                email=data['email'],
                phone=data['phone'],
                password=data['password']
            )
            login(request, user, backend='acg_core.backends.MultiLoginBackend')
            return redirect('/')
    return render(request, 'register.html', {'form': form})

def login_view(request):
    form = LoginForm()
    error = ""
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            # 使用自定义后端进行多方式认证
            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)
                return redirect('/')
            else:
                error = "账号或密码错误"
    return render(request, 'login.html', {'form': form, 'error': error})

from django.contrib.auth import logout # 别忘了导入这个

def logout_view(request):
    logout(request)
    return redirect('index') # 登出后跳回首页