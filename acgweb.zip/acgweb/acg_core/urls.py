from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    # 添加下面这两行
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'), # 顺便把登出也加上
]