from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    phone = models.CharField(max_length=11, unique=True, null=True, blank=True, verbose_name="手机号")
    email = models.EmailField(unique=True, verbose_name="邮箱")

    class Meta:
        # 换成一个新的名字，比如 'acg_user' 或 'custom_user'
        db_table = 'acg_user'